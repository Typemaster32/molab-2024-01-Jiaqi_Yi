//Shader: Menger Journey by  Syntopia https://www.shadertoy.com/user/Syntopia
//Music by <a href="https://pixabay.com/users/studiokolomna-2073170/?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=114322">Denis Maksimov</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=114322">Pixabay</a>

// a shader variable
let theShader;
let shaderBg;

function preload() {
  // load the shader
  theShader = loadShader("shader.vert", "shader.frag");
	soundFormats('mp3', "wav");//load music
  song = loadSound('coolmusic.mp3');
}

function setup() {
	song.play()//Source: Shiffman //plays music at start
  amp = new p5.Amplitude();//Source: Shiffman
	song.loop() //loop music
	
  // disables scaling for retina screens which can create inconsistent scaling between displays
  pixelDensity(1);

  createCanvas(windowWidth, windowHeight);
  noStroke();

  // shaders require WEBGL mode to work
  shaderBg = createGraphics(windowWidth, windowHeight, WEBGL);
  
}
let counter=0
function draw() {
	
	
	var vol = amp.getLevel();//Source: Shiffman
  volumeLevel = map(vol, 0, 0.3,    -.01, .06);//Source: Shiffman - As the volume changes, this variable "volumeLevel" will change as well
	counter=counter+volumeLevel+.01 //counter, as seen on line 55 is esentially the variable for the transition of time the shader starts.
													//here the shader moves at a speed of .01 every frame, in addition, also at the speed of the volume
	
  // we can draw the background each frame or not.
  // if we do we can use transparency in our shader.
  // if we don't it will leave a trailing after image.
  // background(0);
  // shader() sets the active shader with our shader
  shaderBg.shader(theShader);

  // get the mouse coordinates, map them to values between 0-1 space
  let yMouse = (map(mouseY, 0, height, height, 0) / height) * 2 - 1;
  let xMouse = (mouseX / width) * 2 - 1;

  // Make sure pixels are square
  xMouse = (xMouse * width) / height;
  yMouse = yMouse;

  // pass the interactive information to the shader
  theShader.setUniform("iResolution", [width, height]);
  theShader.setUniform("iTime",( counter));
  theShader.setUniform("iMouse", [xMouse, yMouse]);



  // rect gives us some geometry on the screen to draw the shader on
  shaderBg.rect(0, 0, width, height);
  image(shaderBg, 0, 0, width, height);

  // flip coordinate information box
  let flipX = 0;
  let flipY = 0;
  if (width - mouseX < 200) {
    flipX = -130;
  }
  if (height - mouseY < 100) {
    flipY = -35;
  }

  // draw coordinate information box if you want

  /*
  
  fill(255);
  rect(mouseX + flipX, mouseY + flipY, 60, 40);
  fill(0);
  text("x: " + int(mouseX), mouseX + 15 + flipX, mouseY + 15 + flipY);
  text("y: " + int(mouseY), mouseX + 15 + flipX, mouseY + 30 + flipY);
  fill(0);
  rect(mouseX + 60 + flipX, mouseY + flipY, 70, 40);
  fill(255);
  text("x: " + nfc(xMouse, 3), mouseX + 15 + 60 + flipX, mouseY + 15 + flipY);
  text("y: " + nfc(yMouse, 3), mouseX + 15 + 60 + flipX, mouseY + 30 + flipY);

*/

  //console.log(imView);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

let imView = false;

function mousePressed() {
	if(counter>10) counter=random(10000)
  if (imView === false) {
    imView = true;
  }
 // cursor('grabbing');
}

function mouseReleased() {
  if (imView === true) {
    imView = false;
  }
  //cursor('grab');
}