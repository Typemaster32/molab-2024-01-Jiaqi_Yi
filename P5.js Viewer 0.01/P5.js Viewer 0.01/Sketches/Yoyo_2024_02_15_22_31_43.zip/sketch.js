let l=300;
let p;
let s;
let pivots=[]

function setup() {
  createCanvas(600, 600);
  p=new Particle(width/2,height/3*2);
  s=new Spring(width/2,height/3)
  pivots.push(createVector(width/4,height/2))
  pivots.push(createVector(width/4*3,height/2))
}

function draw() {
  background(255);
  for (var i=0;i<pivots.length;i++){
    circle(pivots[i].x,pivots[i].y,3)
  }
  let force = s.makeForce(width/4,height/2,p)
  let gravity = createVector(0, 0.1*p.mass);
  p.applyForce(force)
  p.applyForce(gravity)
  p.update();
  s.update(pivots,p);
  p.show();
  s.show(p);
}

function pointLineDistance(x1, y1, x2, y2, x3, y3) {
  let A = y2 - y1;
  let B = x1 - x2;
  let C = x2*y1 - x1*y2;
  let distance = abs(A*x3 + B*y3 + C) / sqrt(A*A + B*B);
  return distance;
}
function mousePressed(){
  s.fixed=false
}