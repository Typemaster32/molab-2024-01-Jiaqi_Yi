class Spring {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.fixed = true;
    this.pivots = [];
  }

  makeForce(x, y, p) {
    let pivotVector = createVector(0, 0);
    let pivotDistance = 1;
    if (this.pivots.length > 0) {
      x = this.pivots[this.pivots.length].x;
      y = this.pivots[this.pivots.length].y;

      pivotDistance = sqrt(
        (x - p.position.x) * (x - p.position.x) +
          (y - p.position.y) * (y - p.position.y)
      );
      pivotVector = createVector(
        x - p.position.x,
        y - p.position.y
      ).normalize();
      // console.log("1")
    } else {
      pivotDistance = sqrt(
        (this.position.x - p.position.x) * (this.position.x - p.position.x) +
          (this.position.y - p.position.y) * (this.position.y - p.position.y)
      );
      pivotVector = createVector(
        this.position.x - p.position.x,
        this.position.y - p.position.y
      ).normalize();
    }

    // let f = ((p.velocity.mag() * p.velocity.mag()) / pivotDistance) * p.mass;
    let distance = sqrt();
    let streched = max(pivotDistance - l, 0);
    let f = (streched * streched * streched) / 10000;
    let force = pivotVector.copy().mult(f);
    // console.log('1')
    return force;
  }

  // Method to update position
  update(pivots, particle) {
    if (!this.fixed) {
      this.position = createVector(mouseX, mouseY);
    }

    for (let i = 0; i < pivots.length; i++) {
      // console.log("1")
      let pivot = pivots[i];
      let distance = pointLineDistance(
        particle.position.x,
        particle.position.y,
        this.position.x,
        this.position.y,
        pivot.x,
        pivot.y
      );
      if (distance < 1) {
        this.pivots.push(pivot);
        // pivots.splice(i, 1);
      }
    }
    for (let i = 0; i < this.pivots.length; i++) {
      // console.log("2")
      let pivot = this.pivots[i];
      let distance = pointLineDistance(
        particle.position.x,
        particle.position.y,
        this.position.x,
        this.position.y,
        pivot.x,
        pivot.y
      );
      if (distance < 1) {
        // pivots.push(pivot);
        this.pivots.splice(i, 1);
        console.log("3")
      }
    }
  }

  // Method to display
  show(particle) {
    stroke(0);
    strokeWeight(2);
    fill(45, 197, 244);
    ellipse(this.position.x, this.position.y, 3);
    if (this.pivots && this.pivots.length > 0) {
      line(
        this.position.x,
        this.position.y,
        this.pivots[0].x,
        this.pivots[0].y
      );
      for (let i = 0; i < this.pivots.length; i++) {
        let presentPivot = this.pivots[i];
        if (i < this.pivots.length - 1) {
          let nextPivot = this.pivots[i + 1];
          line(
            pivots[i].x,
            this.pivots[i].y,
            this.pivots[i + 1].x,
            this.pivots[i + 1].y
          );
        } else {
          line(
            particle.position.x,
            particle.position.y,
            this.pivots[i].x,
            this.pivots[i].y
          );
        }
      }
    } else {
      line(
        this.position.x,
        this.position.y,
        particle.position.x,
        particle.position.y
      );
    }
  }
}
